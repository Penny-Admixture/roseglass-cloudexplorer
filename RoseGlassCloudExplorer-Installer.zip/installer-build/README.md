# RoseGlass CloudExplorer - Installer 
 
## Installation 
 
1. Run `install.bat` as Administrator 
2. Follow the installation prompts 
3. Launch from Desktop shortcut 
4. Open http://localhost:3000 in your browser 
5. Configure Google Drive when prompted 
 
## Features 
- Robust Google Drive client built on Rclone 
- True cut-paste operations 
- Real-time progress tracking 
- Dual-pane file browser 
- Task queue management 
