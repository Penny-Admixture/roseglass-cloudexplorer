const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const os = require('os');

console.log('RoseGlass CloudExplorer Installer');
console.log('=====================================');

const installDir = path.join('C:', 'Program Files', 'RoseGlass', 'CloudExplorer');
const desktopDir = path.join(os.homedir(), 'Desktop');

try {
  console.log('Creating installation directory...');
  if (!fs.existsSync(installDir)) {
    fs.mkdirSync(installDir, { recursive: true });
  }

  console.log('Copying application files...');
  const sourceDir = path.join(__dirname, 'RoseGlassCloudExplorer');
  copyDir(sourceDir, installDir);

  console.log('Creating desktop shortcut...');
  createShortcut();

  console.log('Adding to system PATH...');
  addToPath(installDir);

  console.log('Installation completed successfully!');
  console.log('You can now run RoseGlass CloudExplorer from the Desktop.');
  console.log('The application will open in your default web browser at http://localhost:3000');
} catch (error) {
  console.error('Installation failed:', error.message);
  process.exit(1);
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function createShortcut() {
  const shortcutPath = path.join(desktopDir, 'RoseGlass CloudExplorer.bat');
  const launcherContent = `@echo off
Starting RoseGlass CloudExplorer...
Please wait while the application starts...
  fs.writeFileSync(shortcutPath, launcherContent);
}

function addToPath(installDir) {
  try {
    const currentPath = process.env.PATH;
    if (!currentPath.includes(installDir)) {
      const newPath = currentPath + ';' + installDir;
      execSync(`setx PATH "${newPath}" /M`, { stdio: 'ignore' });
    }
  } catch (error) {
    console.log('Note: Could not add to system PATH. You may need to restart your computer.');
  }
}
