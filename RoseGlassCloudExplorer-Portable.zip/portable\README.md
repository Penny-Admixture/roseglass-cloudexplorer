# RoseGlass CloudExplorer - Portable Version 
 
## Quick Start 
 
1. Double-click `start.bat` 
2. Open http://localhost:3000 in your browser 
3. Configure Google Drive when prompted 
 
## Features 
- Robust Google Drive client built on Rclone 
- True cut-paste operations 
- Real-time progress tracking 
- Dual-pane file browser 
- Task queue management 
